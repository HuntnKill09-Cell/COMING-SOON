// const AcizeDatabase = require('../../models/Acize.schema');
const app = require("./src/app");
// const counterNetwork = require("./WebhookNetwork/counter");
// const shoutNetwork = require("./WebhookNetwork/shout");
const PORT = 80;

app.listen(PORT, () => {
  console.log(`API listening on PORT ${PORT} `)
})

app.get('/', (req, res) => {
  return res.render('homepage/homepage.html');
})

app.get('/auth', (req, res) => {
  res.render('waitlist/waitlist.html');
});

// Export the Express API
module.exports = app
