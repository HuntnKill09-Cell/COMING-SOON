require("dotenv").config();
const mongoose = require('mongoose')

mongoose.createConnection("mongodb+srv://admin:iPj0LdMpABV6hWHo@cluster0.wmhocqn.mongodb.net/test")