const { Router } = require('express');
const { isAuthorized } = require('../../utils/auth');
const router = Router();
const UserDB = require('../../models/User');

const axios = require('axios');
const Discord = require('discord.js');
let cors = require("cors");
router.use(cors());


router.get('/', async (req, res, next) => {
  res.send('Welcome to the Developer API');
});

router.get('/auth', async (req, res, next) => {
  res.redirect('/auth');
});


module.exports = router;