const { Router } = require("express");
const passport = require("passport");
const router = Router();
const SuspendedDB = require("../../models/Suspended");
const UserDB = require("../../models/User");





router.get("/", passport.authenticate("discord"));

router.get("/logout", (req, res) => {
  if (req.user) req.logout();
  res.redirect("/");
});

router.get(
  "/redirect",
  passport.authenticate("discord", {
    failureRedirect: "/", //other you could use are /forbiddent,/failure, etc
    successRedirect: "/app/waitlist",
  })
);

//hi





module.exports = router;