const { Router } = require("express");
const { isNotAuthorized } = require("../../utils/auth");
const { isAuthorized, checkSuspended } = require("../../utils/auth");
const router = Router();
const SuspendedDB = require("../../models/Suspended");
const UserDB = require("../../models/User");

router.get("/", isNotAuthorized, (req, res) => {
    
    res.render('../views/homepage/homepage.html')
});
router.get("/careers", (req, res) => {
   res.redirect("https://forms.gle/HA6mvCpdCrLHwsqm6")
} )
router.get("/app/waitlist", isAuthorized, async (req, res) => {
   const discordUser = await SuspendedDB.findOne({ discordId: req.user.discordId });
   const discordUser2 = await UserDB.findOne({ discordId: req.user.discordId });
    
   if(discordUser) {
      res.redirect('/access/notice')
   } else {
      res.render("../views/waitlist/waitlist.html", {
         user: req.user,
         discordId: req.user.discordId
       });
   }
   
  }) 
  
  
  router.get("/", isAuthorized, async (req, res) => {
     const discordUser = await SuspendedDB.findOne({ discordId: req.user.discordId });
     const discordUser2 = await UserDB.findOne({ discordId: req.user.discordId });
  
  
     const today = new Date();
     const day = today.getDate();        // 24
     const month = today.getMonth();
     const year = today.getFullYear();
  
     const newMonth = month + 1
  
     if (discordUser) {
        return res.render("suspended/notice.html", {
           data: discordUser,
           user: discordUser2,
        });
     } else {
        return res.redirect("/app/waitlist")
     }
   })
  module.exports = router;









