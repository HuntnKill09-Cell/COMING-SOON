const { Router } = require("express");
const { isAuthorized, checkSuspended } = require("../../utils/auth");
const router = Router();
const SuspendedDB = require("../../models/Suspended");
const UserDB = require("../../models/User");

router.get("/", isAuthorized, async (req, res) => {
   const discordUser = await SuspendedDB.findOne({ discordId: req.user.discordId });
   const discordUser2 = await UserDB.findOne({ discordId: req.user.discordId });


   const today = new Date();
   const day = today.getDate();        // 24
   const month = today.getMonth();
   const year = today.getFullYear();

   const newMonth = month + 1

   console.log(discordUser)

   if (discordUser) {
      return res.render("suspended/notice.html", {
         data: discordUser,
         user: discordUser2,
      });
   } else {
      return res.redirect("/app/waitlist")
   }
});

module.exports = router;