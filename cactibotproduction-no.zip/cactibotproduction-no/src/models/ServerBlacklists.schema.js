const mongoose = require('mongoose');

const memberCounterSchema = new mongoose.Schema({
  serverId: String
})

module.exports = mongoose.models['guildbans'] || mongoose.model('guildbans', memberCounterSchema, 'guildbans');