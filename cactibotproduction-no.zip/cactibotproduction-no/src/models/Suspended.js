const { Schema, model } = require("mongoose");
const userSchema = new Schema({
    discordId: String,
    reason: String,
});
module.exports = model("suspensions", userSchema);