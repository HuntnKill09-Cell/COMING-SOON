const { Schema, model } = require("mongoose");
const userSchema = new Schema({
    discordId: String,
    username: String,
    discriminator: String,
    avatar: String,
    accessToken: String,
    session: String,
});
module.exports = model("users", userSchema);