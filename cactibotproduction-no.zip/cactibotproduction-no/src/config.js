

module.exports = {
    PORT: 80,
    MONGODB_URI: "mongodb+srv://admin:iPj0LdMpABV6hWHo@cluster0.wmhocqn.mongodb.net/test",
    SECRET: "29038eiosdjkfqw98efu930q48ruio*(&#$*()@EIFDHJWSD*(FW()ESDf",
    DISCORD_CLIENT_ID: '1038848553319149568 ',
    DISCORD_CLIENT_SECRET: 'cNF6HwBMWO54M7bzL2OwqJ218ItNESZs',
    DISCORD_CLIENT_REDIRECT: '/auth/redirect'
}