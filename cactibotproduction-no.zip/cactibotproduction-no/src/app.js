const express = require("express");
const session = require("express-session");
const passport = require("passport");
const path = require("path");
const ejs = require("ejs");
const MongoStore = require("connect-mongo");
const { SECRET, MONGODB_URI, PASSWORD } = require("./config");
const { isAuthorized } = require("./utils/auth");
const app = express();
require("./strategies/discordStrategy");


app.engine("html", ejs.renderFile);
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

//app.get('/favicon.ico', (req, res) => res.status(204));


app.use(
    session({
      secret: SECRET,
      cookie: {
        maxAge: 60000 * 60 * 24, // 1 day
      //  secure: true
      },
      saveUninitialized: false,
      resave: true,
      name: "Secure_Session",
      store: MongoStore.create({
        mongoUrl: MONGODB_URI,
      }),
    })
  );

app.use(passport.initialize());
app.use(passport.session());

app.use((req, res, next) => {
    app.locals.user = req.user;
    res.status(200)
    next();
})


app.use("/", require("./routes/platform/index.routes"));
app.use("/auth", require("./routes/auth/auth.routes"));
app.use("/api", require("./routes/auth/api.routes"));
app.use("/access/notice", require("./routes/access/notice.routes"));

const { connect } = require("mongoose");
  
connect(MONGODB_URI)
  .then((db) => console.log(db.connection.name))
  .catch((err) => console.error(err));






module.exports = app;