

function isAuthorized(req, res, next) {
  if (req.user) {
    
   const UserDB = require('../models/User');
   UserDB.findOneAndUpdate({ discordId: `${req.user.id}` }, { avatar: `${req.user.avatar}` })
    
    console.log("User is logged in");
    console.log(req.user);
    return next();
    
    
    
    
  } else {
    return res.redirect("/");
  }
}


async function checkSuspended(req, res, next) {
  let { data: blacklists2, error2 } = await supabase
  .from('blacklists')
  .select('*')
  
 let documentsBlacklists = await blacklists2
  
  documentsBlacklists.forEach(async (doc, i) => {
    if(doc.userId === req.user.discordId){
      next()
    }else{
      res.redirect("/waitlist")
    }
  })
}

function isNotAuthorized(req, res, next) {
  if (req.user) {
    // console.log("User is logged in");
    res.redirect("/app/waitlist");
  } else {
    next();
  }
}

module.exports = {
  isAuthorized,
  isNotAuthorized,
  checkSuspended,
};