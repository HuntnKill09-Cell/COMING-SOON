const { Strategy } = require("passport-discord");
const passport = require("passport");
const User = require("../models/User");
const Discord = require("discord.js")
const Suspend = require("../models/Suspended");
const Blacklists = require("../models/ServerBlacklists.schema");
const axios = require('axios')
const refresh = require('passport-oauth2-refresh');
const {
  DISCORD_CLIENT_ID,
  DISCORD_CLIENT_SECRET,
  DISCORD_CLIENT_REDIRECT,
} = require("../config");

passport.serializeUser((user, done) => {
  done(null, user.id);
});

passport.deserializeUser(async (id, done) => {
  const user = await User.findById(id);
  if (user) done(null, user);
});

passport.use(new Strategy(

  {
    clientID: DISCORD_CLIENT_ID,
    clientSecret: DISCORD_CLIENT_SECRET,
    callbackURL: DISCORD_CLIENT_REDIRECT,
    scope: ["identify", "guilds"],
  },
  async (accessToken, refreshToken, profile, done) => {
    console.log(accessToken, refreshToken)
 
    const discordUser = await User.findOne({ discordId: profile.id })
    if (discordUser) {

      const id = '1029552797693263873';
      const token = 'A3kiUXN4v0WPuLwfNfwAV4j5X3WANMrlQpPgQx315jmyarH_wtHgK5LleIMFnvQAr0_1';

     

      console.log("hi")

      const newUser = await User.create({
        discordId: profile.id,
        username: profile.username,
        avatar: profile.avatar,
        discriminator: profile.discriminator,
        accessToken: `${accessToken}`,
        session: `${refreshToken}`,
      });

    return done(null, newUser);
    }else{

      console.log("hi")

      const newUser = await User.create({
        discordId: profile.id,
        username: profile.username,
        avatar: profile.avatar,
        discriminator: profile.discriminator,
        accessToken: `${accessToken}`,
        session: `${refreshToken}`,
      });

      return done(null, newUser);


    }
  }
))